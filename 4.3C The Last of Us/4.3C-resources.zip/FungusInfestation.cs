﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;

namespace FungusInfestation
{
    public class FungusInfestation
    {

        public static int Solve(string[] matrix)
        {
            //Add your code here!
            throw new NotImplementedException();
        }

    }
}